library(scales)
library(plotrix)

ymmmmax<<-0
x <- matrix(1:300)
x2<- matrix(1:300)

layout(matrix(1:9, ncol = 3,nrow = 3), widths = c(3,2.5,2.75), heights = c(3,2.25,3), respect = FALSE)

load(file='~/Downloads/10a.rda')
yLSTM=yLSTM[1:length(x)]/2772
ymaxLSTM=ymaxLSTM[1:length(x)]/2772
yminLSTM=yminLSTM[1:length(x)]/2772
yela=yela[1:length(x)]/2772
ymaxela=ymaxela[1:length(x)]/2772
yminela=yminela[1:length(x)]/2772
yDNN=yDNN[1:length(x)]/2772
ymaxDNN=ymaxDNN[1:length(x)]/2772
yminDNN=yminDNN[1:length(x)]/2772
yXG=yXG[1:length(x)]/2772
ymaxXG=ymaxXG[1:length(x)]/2772
yminXG=yminXG[1:length(x)]/2772
ySVM=ySVM[1:length(x)]/2772
ymaxSVM=ymaxSVM[1:length(x)]/2772
yminSVM=yminSVM[1:length(x)]/2772

par(mar = c(0, 4.1, 4.1, 0))
with(
  plot(x, yDNN, type = "l", col = "chartreuse4", xlim = c(0, length(x)),ylim = c(0,0.05), main="StatusTest (10%)",xaxt="n",yaxt="n",
            # xlab = "Number of relevants selected",
            ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
yticks_val <- pretty_breaks(n=10)(c(0:5)/100)
axis(2, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
# lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yDNN[kk])&(yminela[kk]>ymaxDNN[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yDNN[kk])&(yminDNN[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="chartreuse4",cex=0.1)
}



load(file='~/Downloads/10co.rda')
yLSTM=yLSTM[1:length(x)]/656
ymaxLSTM=ymaxLSTM[1:length(x)]/656
yminLSTM=yminLSTM[1:length(x)]/656
yela=yela[1:length(x)]/656
ymaxela=ymaxela[1:length(x)]/656
yminela=yminela[1:length(x)]/656
yDNN=yDNN[1:length(x)]/656
ymaxDNN=ymaxDNN[1:length(x)]/656
yminDNN=yminDNN[1:length(x)]/656
yXG=yXG[1:length(x)]/656
ymaxXG=ymaxXG[1:length(x)]/656
yminXG=yminXG[1:length(x)]/656
ySVM=ySVM[1:length(x)]/656
ymaxSVM=ymaxSVM[1:length(x)]/656
yminSVM=yminSVM[1:length(x)]/656

par(mar = c(0, 4.1, 0, 0))
with(
  plot(x, yDNN, type = "l", col = "chartreuse4", xlim = c(0, length(x)),ylim = c(0,0.15),xaxt="n",yaxt="n",
       # xlab = "Number of relevants selected",
         ylab = "Actual hits (COPD)",cex.lab=1.2,cex.main=1.2)
)
yticks_val <- pretty_breaks(n=10)(c(0:15)/100)
axis(2, at=yticks_val, lab=percent(yticks_val))
     
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
# lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")

for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}

load(file='~/Downloads/10ca.rda')
yLSTM=yLSTM[1:length(x)]/119
ymaxLSTM=ymaxLSTM[1:length(x)]/119
yminLSTM=yminLSTM[1:length(x)]/119
yela=yela[1:length(x)]/119
ymaxela=ymaxela[1:length(x)]/119
yminela=yminela[1:length(x)]/119
yDNN=yDNN[1:length(x)]/119
ymaxDNN=ymaxDNN[1:length(x)]/119
yminDNN=yminDNN[1:length(x)]/119
yXG=yXG[1:length(x)]/119
ymaxXG=ymaxXG[1:length(x)]/119
yminXG=yminXG[1:length(x)]/119
ySVM=ySVM[1:length(x)]/119
ymaxSVM=ymaxSVM[1:length(x)]/119
yminSVM=yminSVM[1:length(x)]/119

par(mar = c(4.1, 4.1, 0, 0))
with(
  plot(x = x, y = yDNN, col = "chartreuse4", type = "l", xlim = c(0, length(x)), ylim = c(0,0.20),yaxt="n",
       xlab = "",
       ylab = "Actual hits (Cancer)",cex.lab=1.2,cex.main=1.2)
 
)
yticks_val <- pretty_breaks(n=10)(c(0:20)/100)
axis(2, at=yticks_val, lab=percent(yticks_val))

polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
# lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")

for (kk in 1:length(x)) {
  if ((yela[kk]>yDNN[kk])&(yminela[kk]>ymaxDNN[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yDNN[kk])&(yminDNN[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="chartreuse4",cex=0.1)
}

x <- matrix(1:1500)
x2<- matrix(1:1500)

load(file='~/Downloads/50a.rda')
yLSTM=yLSTM[1:length(x)]/13852
ymaxLSTM=ymaxLSTM[1:length(x)]/13852
yminLSTM=yminLSTM[1:length(x)]/13852
yela=yela[1:length(x)]/13852
ymaxela=ymaxela[1:length(x)]/13852
yminela=yminela[1:length(x)]/13852
yDNN=yDNN[1:length(x)]/13852
ymaxDNN=ymaxDNN[1:length(x)]/13852
yminDNN=yminDNN[1:length(x)]/13852
yXG=yXG[1:length(x)]/13852
ymaxXG=ymaxXG[1:length(x)]/13852
yminXG=yminXG[1:length(x)]/13852
ySVM=ySVM[1:length(x)]/13852
ymaxSVM=ymaxSVM[1:length(x)]/13852
yminSVM=yminSVM[1:length(x)]/13852

par(mar = c(0, 0, 4.1,0 ))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.05),main="StatusTest (50%)",,xaxt="n",yaxt="n",
       # xlab = "Number of relevants selected",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yDNN[kk])&(yminela[kk]>ymaxDNN[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yDNN[kk])&(yminDNN[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="chartreuse4",cex=0.1)
}


load(file='~/Downloads/50co.rda')
yLSTM=yLSTM[1:length(x)]/3227
ymaxLSTM=ymaxLSTM[1:length(x)]/3227
yminLSTM=yminLSTM[1:length(x)]/3227
yela=yela[1:length(x)]/3227
ymaxela=ymaxela[1:length(x)]/3227
yminela=yminela[1:length(x)]/3227
yDNN=yDNN[1:length(x)]/3227
ymaxDNN=ymaxDNN[1:length(x)]/3227
yminDNN=yminDNN[1:length(x)]/3227
yXG=yXG[1:length(x)]/3227
ymaxXG=ymaxXG[1:length(x)]/3227
yminXG=yminXG[1:length(x)]/3227
ySVM=ySVM[1:length(x)]/3227
ymaxSVM=ymaxSVM[1:length(x)]/3227
yminSVM=yminSVM[1:length(x)]/3227

par(mar = c(0, 0, 0, 0 ))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.15),xaxt="n",yaxt="n",
       # xlab = "Number of relevants selected",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}


load(file='~/Downloads/50ca.rda')
yLSTM=yLSTM[1:length(x)]/600
ymaxLSTM=ymaxLSTM[1:length(x)]/600
yminLSTM=yminLSTM[1:length(x)]/600
yela=yela[1:length(x)]/600
ymaxela=ymaxela[1:length(x)]/600
yminela=yminela[1:length(x)]/600
yDNN=yDNN[1:length(x)]/600
ymaxDNN=ymaxDNN[1:length(x)]/600
yminDNN=yminDNN[1:length(x)]/600
yXG=yXG[1:length(x)]/600
ymaxXG=ymaxXG[1:length(x)]/600
yminXG=yminXG[1:length(x)]/600
ySVM=ySVM[1:length(x)]/600
ymaxSVM=ymaxSVM[1:length(x)]/600
yminSVM=yminSVM[1:length(x)]/600

par(mar = c(4.1, 0, 0, 0 ))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.20),yaxt="n",
       xlab = "Number of relevants selected",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}


x <- matrix(1:3000)
x2<- matrix(1:3000)

load(file='~/Downloads/100a.rda')
yLSTM=yLSTM[1:length(x)]/27692
ymaxLSTM=ymaxLSTM[1:length(x)]/27692
yminLSTM=yminLSTM[1:length(x)]/27692
yela=yela[1:length(x)]/27692
ymaxela=ymaxela[1:length(x)]/27692
yminela=yminela[1:length(x)]/27692
yDNN=yDNN[1:length(x)]/27692
ymaxDNN=ymaxDNN[1:length(x)]/27692
yminDNN=yminDNN[1:length(x)]/27692
yXG=yXG[1:length(x)]/27692
ymaxXG=ymaxXG[1:length(x)]/27692
yminXG=yminXG[1:length(x)]/27692
ySVM=ySVM[1:length(x)]/27692
ymaxSVM=ymaxSVM[1:length(x)]/27692
yminSVM=yminSVM[1:length(x)]/27692

par(mar = c(0, 0, 4.1, 2.1))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.05),main="StatusTest (100%)",,xaxt="n",yaxt="n",
       # xlab = "Number of relevants selected",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}


load(file='~/Downloads/100co.rda')
yLSTM=yLSTM[1:length(x)]/6449
ymaxLSTM=ymaxLSTM[1:length(x)]/6449
yminLSTM=yminLSTM[1:length(x)]/6449
yela=yela[1:length(x)]/6449
ymaxela=ymaxela[1:length(x)]/6449
yminela=yminela[1:length(x)]/6449
yDNN=yDNN[1:length(x)]/6449
ymaxDNN=ymaxDNN[1:length(x)]/6449
yminDNN=yminDNN[1:length(x)]/6449
yXG=yXG[1:length(x)]/6449
ymaxXG=ymaxXG[1:length(x)]/6449
yminXG=yminXG[1:length(x)]/6449
ySVM=ySVM[1:length(x)]/6449
ymaxSVM=ymaxSVM[1:length(x)]/6449
yminSVM=yminSVM[1:length(x)]/6449

par(mar = c(0, 0, 0, 2.1 ))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.15),xaxt="n",yaxt="n",
       # xlab = "Number of relevants selected",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}


load(file='~/Downloads/100ca.rda')
yLSTM=yLSTM[1:length(x)]/1202
ymaxLSTM=ymaxLSTM[1:length(x)]/1202
yminLSTM=yminLSTM[1:length(x)]/1202
yela=yela[1:length(x)]/1202
ymaxela=ymaxela[1:length(x)]/1202
yminela=yminela[1:length(x)]/1202
yDNN=yDNN[1:length(x)]/1202
ymaxDNN=ymaxDNN[1:length(x)]/1202
yminDNN=yminDNN[1:length(x)]/1202
yXG=yXG[1:length(x)]/1202
ymaxXG=ymaxXG[1:length(x)]/1202
yminXG=yminXG[1:length(x)]/1202
ySVM=ySVM[1:length(x)]/1202
ymaxSVM=ymaxSVM[1:length(x)]/1202
yminSVM=yminSVM[1:length(x)]/1202

par(mar = c(4.1, 0, 0, 2.1 ))
with(
  plot(1, 1, type = "n", xlim = c(0, length(x)), ylim = c(0,0.20),yaxt="n",
       xlab = "",
       ylab = "Actual hits (Asthma)",cex.lab=1.2,cex.main=1.2)
)
polygon(x = c(x,rev(x)), y = c(ymaxDNN,rev(yminDNN)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border = NA)
polygon(x = c(x,rev(x)), y = c(ymaxSVM,rev(yminSVM)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxXG,rev(yminXG)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
polygon(x = c(x2,rev(x2)), y = c(ymaxela,rev(yminela)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)

#polygon(x = c(x,rev(x)), y = c(ymaxLSTM,rev(yminLSTM)), col = adjustcolor("yellow", alpha.f = 0.05), border = 'black')
#polygon(x = x, y = ymax, col = adjustcolor("blue", alpha.f = 0.05), border = 'red')
lines(x = x, y = yDNN, col = "chartreuse4")
lines(x = x, y = ySVM, col = "purple")
lines(x = x, y = yXG, col = "red")
lines(x = x, y = yLSTM, col = "royalblue2")#画出平均值曲线
lines(x = x2, y = yela, col = "orange")
for (kk in 1:length(x)) {
  if ((yela[kk]>yLSTM[kk])&(yminela[kk]>ymaxLSTM[kk]))
    points(kk,0,pch=20,col="brown",cex=0.1)
  
  else if ((yela[kk]<yLSTM[kk])&(yminLSTM[kk]>ymaxela[kk]))
    points(kk,0,pch=20,col="royalblue2",cex=0.1)
}




