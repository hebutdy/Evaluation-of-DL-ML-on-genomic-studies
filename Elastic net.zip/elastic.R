#library package
library(MTPS)
library(ROCR)
library(rpart)
library(rpart.plot)
#read data
ukbb1 <- read.csv(file="/lustre06/project/6003851/pyroli77/Routput/data2/train10%.csv",header = T)
ukbb1 <- ukbb1[complete.cases(ukbb1),]
ukbb2 <- ukbb1[,-1]
ukbb5 <-ukbb2[,-7:-8]
XX <- ukbb2[,-6:-8]
YY1 <- ukbb2[,6] #asthma
YY2 <- ukbb2[,7] #COPD
YY3 <- ukbb2[,8] #cancer
x.train <- as.matrix(XX)
y.train <- as.matrix(YY1)

ukbb3 <- read.csv(file="/lustre06/project/6003851/pyroli77/Routput/data2/test10%.csv",header = T)
ukbb3 <- ukbb3[complete.cases(ukbb3),]
ukbb4 <- ukbb3[,-1]
ukbb6 <-ukbb4[,-7:-8]
XXX <- ukbb4[,-6:-8]
YYY1 <- ukbb4[,6] #asthma
YYY2 <- ukbb4[,7] #COPD
YYY3 <- ukbb4[,8] #cancer
x.test <- as.matrix(XXX)
y.test <- as.matrix(YYY1)

###########check if VAR = 0#########
# Xsnp=XX[,-1:-5]
# 
# VAR<- matrix(0, nrow = ncol(Xsnp), 1)
# for (i in 1:ncol(Xsnp)){
#   VAR[i,]<-var(Xsnp[ ,i])
# }
# # summary(VAR)
# Vs=order(VAR)
# sort(VAR)[1501]
# Xtop200=Xsnp[,c(VAR>=sort(VAR)[1501])]
# XX2=cbind(XX[,1:5],Xtop200)
# XXX2=cbind(XXX[,1:5],XXX[,-1:-5][,c(VAR>=sort(VAR)[1501])])

# VAR1<- matrix(0, nrow = ncol(Xtop200), 1)
# for (i in 1:ncol(Xtop200)){
#   VAR1[i,]<-var(Xtop200[ ,i])
# }
# summary(VAR1)

##########generate 10 different version of 10-fold splits##########
set.seed(1)
nrep=10 # replication 10 times
nfolds=10 # 10-fold Cross valiation 

###############################################################################
###you don't need regenerate this idx.cv, you can read the file "idx_cv.csv"###
idx.cv=matrix(NA,nrow=nrow(y.train),ncol=nrep)
for(i in 1:nrep){
  idx.cv[,i]=createFolds(y.train[,1],k=nfolds,list = F)
}
#save the idx.cv
# write.csv(idx.cv,file="idx_cv.csv")
###you don't need regenerate this idx.cv, you can read the file "idx_cv.csv"###
###############################################################################

###"idx_cv.csv" can be read by read.csv()
###idx.cv=read.csv(file="idx_cv.csv",row.names = 1)

##########find the fix lambda and alpha for binary elastic net ##########

# cv.asthma=cv.glmnet2(x.train,y.train,foldid=NULL,alpha=seq(1,9,by=1)/10,family="binomial")
cv.asthma=cv.glmnet2(x.train,y.train,foldid=NULL,alpha=seq(1,9,by=1)/10,family="binomial",type.measure="auc")
# cv.asthma=cv.glmnet2(x.train,y.train,foldid=NULL,alpha=seq(1,9,by=1)/10,family="binomial",type.measure="class")

lambda.fix.asthma=cv.asthma$lambda.min
alpha.fix.asthma=cv.asthma$alpha

##########create matrix that will save the predict result##########
#predict probability
y.vald=matrix(NA,nrow=nrow(idx.cv),ncol=1)

#F1 score 
co=seq(1,999,by=1)/1000

F1=matrix(NA,nrow = nrep,ncol =length(co))


##########fit model##########
# nrep=1
for(ii in 1:nrep){
  for(jj in 1:nfolds){
    
    x.tr=as.matrix(x.train[idx.cv[,ii]!=jj,])
    x.v=as.matrix(x.train[idx.cv[,ii]==jj,])
    
    y.tr=as.matrix(as.matrix(y.train[idx.cv[,ii]!=jj,1]))
    y.v=as.matrix(y.train[idx.cv[,ii]==jj,1])
    ela.asthma=glmnet(x.tr,y.tr,family = "binomial",alpha = alpha.fix.asthma,lambda = lambda.fix.asthma)
    y.vald[idx.cv[,ii]==jj,1]=predict(ela.asthma,x.v,type = "response")
    
    
  }
  
  for (kk in 1:length(co)) {
    
    tp=length(which(y.train[,1]=="1"&y.vald[,1]>=co[kk]))#true positive
    fp=length(which(y.train[,1]!="1"&y.vald[,1]>=co[kk]))#false positive
    fn=length(which(y.train[,1]=="1"&y.vald[,1]<co[kk]))#false negative
    precision.binary=tp/(tp+fp)#precision.binary
    recall.binary=tp/(tp+fn)#recall.binary
    F1[ii,kk]=2*(precision.binary*recall.binary)/(precision.binary+recall.binary)#F1.B_Cells score
  }
}
############choose cut off ##########################

F1.avg=colMeans(F1)
cutoff.asthma=co[which(F1.avg==max(F1.avg,na.rm = T))][1]

###################test model######################
fit.asthma=glmnet(x.train,y.train,family = "binomial",alpha = alpha.fix.asthma,lambda = lambda.fix.asthma)
y.pred=predict(fit.asthma,x.test,type = "response")


# pred.bin=rep(0,length(y.pred))
# pred.bin[which(y.pred >= cutoff.asthma)]=1
# 
# pred.asthma <- prediction (pred.bin,y.test)
# perf.asthma <- performance(pred.asthma,"tpr","fpr")
# plot(perf.asthma, col="blue",lty=3, lwd=3, main="ROC plot")
# auc.asthma = performance(pred.asthma,"auc")
# auc.asthma = unlist(slot(auc.asthma, "y.values"))


# trapezoid integration of area under FPR vs TPR curve, truncated at cc
trapezoid<- function(FPR,TPR,cc) 
{
  ordFPR=order(FPR)
  FPR=FPR[ordFPR]
  TPR=TPR[ordFPR]
  if (max(FPR)<cc)
  {
    #print("warning: cut point is outside of FPR range, all points are used")
    FPRcut=FPR
    TPRcut=TPR
  }else if(min(FPR)>cc)
  {
    stop("threshold smaller than smallest allowed value")
  }else
  {
    FPRlcc=sum(FPR<cc)
    FPR1=FPR[FPRlcc]; FPR2=FPR[FPRlcc+1]
    TPR1=FPR[FPRlcc]; TPR2=TPR[FPRlcc+1]
    TPRcc=( TPR1*(cc-FPR1) + TPR2*(FPR2-cc) ) / (FPR2-FPR1)
    FPRcut=c(FPR[1:FPRlcc],cc)
    TPRcut=c(TPR[1:FPRlcc],TPRcc)
  }
  return(sum( diff(FPRcut) * ( TPRcut[-1] + head(TPRcut,-1) ) )/2)
}

##########################################################
## Calculate AUC statistics and optional plot ROC curve
# Using all posible threshold to classify records based on predicted probability (prob)
# We calculate TPR and FPR for each corresponding threshold value
# Connect the TPR vs FPR curve, we obtain ROC curve
# We calculate area under ROC curve (i.e. AUC statistics)
# cutoff can truncate ROC curve to only allow prediction with certain level of specificity
# common choice of cutoff can be 1 (i.e. no truncate) or 0.2 (i.e. specificity > 0.8)
# definition: https://en.wikipedia.org/wiki/Receiver_operating_characteristic
############### 
## Input
# prob: predicted probability
# bin: observed binary outcome
# cutoff: where should the ROC curve be truncated (i.e. truncated at FPR< cutoff)
# ROC: indicator or whether or not to plot ROC curve
###############
## Output
# AUC statistics, and optional plot of ROC curve
########################################################
AUC <- function(prob, bin, cutoff=1, ROC=F)
{
  NN <- length(bin)
  if(length(prob)!=NN) stop("prob and binary should be the same length")
  if((max(prob)>1) | (min(prob)<0)) stop("prob values should be in [0,1]")
  
  # remove missing values, which cannot contribute to AUC calculation
  idx.retain <- (!is.na(bin)) & (!is.na(prob))
  prob <- prob[idx.retain]
  bin  <-  bin[idx.retain]
  
  # sort binary outcome by order of predicted probability
  ord <- order(prob, decreasing=T)
  prob <- prob[ord]
  bin <- bin[ord]
  
  
  CP <- sum(bin)    # condition positive
  CN <- NN-sum(bin) # condition negative
  TP <- cumsum(bin) # true positive
  FP <- (1:NN) - cumsum(bin) # false Positve
  TPR <- TP/CP		 # True positive rate (sensitivity)
  FPR <- FP/CN		 # False positive rate (1- specificity)
  if(ROC) {plot(FPR, TPR); abline(v=cutoff)}
  auc <- trapezoid(FPR, TPR, cutoff)
  
  return(auc)
}

auc.asthma=AUC(y.pred,y.test,cutoff = cutoff.asthma)

tp.asthma=length(which(y.test[,1]=="1"&y.pred[,1]>=cutoff.asthma))#true positive
fp.asthma=length(which(y.test[,1]!="1"&y.pred[,1]>=cutoff.asthma))#false positive
fn.asthma=length(which(y.test[,1]=="1"&y.pred[,1]<cutoff.asthma))#false negative
precision.asthma=tp.asthma/(tp.asthma+fp.asthma)
recall.asthma=tp.asthma/(tp.asthma+fn.asthma)
F1.asthma=2*(precision.asthma*recall.asthma)/(precision.asthma+recall.asthma)

cat("asthma, 10%, elastic net\n")
cat("alpha =", alpha.fix.asthma,"\n")
cat("lambda =", lambda.fix.asthma,"\n")
cat("The cut off value that maximizes the F1 score is:", co[which(F1.avg==max(F1.avg,na.rm = T))],"\n")
cat("AUC =", auc.asthma,"\n")
cat("TP =", tp.asthma,"\n")
cat("FP =", fp.asthma,"\n")
cat("FN =", fn.asthma,"\n")
cat("Precision of Asthma =", precision.asthma,"\n")
cat("Recall of Asthma =", recall.asthma,"\n")
cat("F1 score of Asthma =", F1.asthma,"\n")







