library(scales)
library(plotrix)
x<-c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)
precision.en<-c(0.2404,0.2433,0.2416,0.2445,0.2410,0.2416,0.2436,0.2453,0.2459,0.2444)
psd.en<-c(0.0127,0.0087,0.0078,0.0091,0.0070,0.0087,0.0082,0.0068,0.0078,0.0055)
precision.xg<-c(0.2343,0.2412,0.2424,0.2448,0.2419,0.2443,0.2448,0.2466,0.2438,0.2446)
psd.xg<-c(0.0163,0.0057,0.0057,0.0093,0.0085,0.0084,0.0049,0.0058,0.0045,0.0044)
precision.svm<-c(0.1701,0.1903,0.2004,0.2074,0.2108,0.2175,0.2181,0.2229,0.2229,0.2257)
psd.svm<-c(0.0092,0.0057,0.0047,0.0066,0.0049,0.0055,0.0062,0.0059,0.0048,0.0032)
precision.lstm<-c(0.2036,0.2323,0.2373,0.2424,0.2382,0.2415,0.2367,0.2430,0.2377,0.2364)
psd.lstm<-c(0.0125,0.021,0.0090,0.0096,0.0029,0.0090,0.0094,0.0051,0.0031,0.0073)
precision.dnn<-c(0.1907,0.2235,0.2235,0.2239,0.2241,0.2305,0.2292,0.2345,0.2364,0.2380)
psd.dnn<-c(0.0143,0.0033,0.0049,0.0087,0.0062,0.0072,0.0104,0.0120,0.0045,0.0096)


recall.en<-c(0.4535,0.4710,0.4729,0.4687,0.4836,0.4801,0.4751,0.4710,0.4671,0.4657)
rsd.en<-c(0.0307,0.0238,0.0197,0.0270,0.0189,0.0155,0.0175,0.0214,0.0226,0.0148)
recall.xg<-c(0.4505,0.4501,0.4537,0.4550,0.4755,0.4644,0.4638,0.4595,0.4686,0.4669)
rsd.xg<-c(0.0360,0.0286,0.0213,0.0301,0.0264,0.0214,0.0148,0.0182,0.0102,0.0141)
recall.svm<-c(0.4800,0.4847,0.4888,0.4807,0.4844,0.4850,0.4851,0.4856,0.4880,0.4904)
rsd.svm<-c(0.0126,0.0131,0.0132,0.0180,0.0112,0.0220,0.0085,0.0177,0.0129,0.0094)
recall.lstm<-c(0.1780,0.2787,0.3553,0.3931,0.4398,0.4356,0.4575,0.4416,0.4457,0.4559)
rsd.lstm<-c(0.0234,0.0232,0.0259,0.0305,0.0227,0.0309,0.0217,0.0184,0.0278,0.0243)
recall.dnn<-c(0.4635,0.4654,0.4706,0.4665,0.4803,0.4781,0.4815,0.4638,0.4605,0.4542)
rsd.dnn<-c(0.0432,0.0166,0.0315,0.0412,0.0286,0.0299,0.0353,0.0347,0.0168,0.0276)




f1.en<-c(0.3135,0.3187,0.3195,0.3208,0.3214,0.3211,0.3217,0.3222,0.3218,0.3204)
fsd.en<-c(0.0098,0.0071,0.0046,0.0047,0.0047,0.0056,0.0040,0.0029,0.0031,0.0019)
f1.xg<-c(0.3097,0.3137,0.3155,0.3177,0.3201,0.3198,0.3203,0.3207,0.3206,0.3209)
fsd.xg<-c(0.0123,0.0086,0.0055,0.0061,0.0047,0.0051,0.0015,0.0030,0.0026,0.0029)
f1.svm<-c(0.2635,0.2794,0.2886,0.2944,0.2966,0.3006,0.3028,0.3048,0.3061,0.3066)
fsd.svm<-c(0.0129,0.0036,0.0054,0.0057,0.0043,0.0051,0.0042,0.0034,0.0033,0.0031)
f1.lstm<-c(0.1891,0.2587,0.2840,0.2992,0.3088,0.3101,0.3115,0.3133,0.3098,0.3112)
fsd.lstm<-c(0.0142,0.0118,0.0096,0.0095,0.0060,0.0066,0.0057,0.0030,0.0063,0.0031)
f1.dnn<-c(0.2828,0.3034,0.3072,0.3106,0.3098,0.3117,0.3095,0.3105,0.3118,0.3117)
fsd.dnn<-c(0.0121,0.0063,0.0069,0.0055,0.0032,0.0048,0.0053,0.0051,0.0047,0.0045)



layout(matrix(1:9, ncol = 3,nrow = 3), widths = c(3,2.5,2.75), heights = c(3,2.5,3), respect = FALSE)
par(mar = c(0, 6.1, 4.1, 0))
with(
  plot(x,precision.en, type = "b",col = "orange", font.main=1,main="Asthma (27692/205238)",ylim = c(0,0.4),xaxt="n",
       ylab = "Precision",cex.lab=2,cex.main=2,cex.axis=2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(precision.en+psd.en,rev(precision.en-psd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,precision.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(precision.xg+psd.xg,rev(precision.xg-psd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,precision.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(precision.svm+psd.svm,rev(precision.svm-psd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,precision.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(precision.lstm+psd.lstm,rev(precision.lstm-psd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,precision.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(precision.dnn+psd.dnn,rev(precision.dnn-psd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(0, 6.1, 0, 0))
with(plot(x,recall.en, type = "b",col = "orange", ylim = c(0,0.5),xaxt="n",
          ylab = "Recall",cex.lab=2,cex.main=2,cex.axis=2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(recall.en+rsd.en,rev(recall.en-rsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,recall.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(recall.xg+rsd.xg,rev(recall.xg-rsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,recall.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(recall.svm+rsd.svm,rev(recall.svm-rsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,recall.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(recall.lstm+rsd.lstm,rev(recall.lstm-rsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,recall.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(recall.dnn+rsd.dnn,rev(recall.dnn-rsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(6.1, 6.1, 0, 0))
plot(x,f1.en, type = "b",col = "orange", ylim = c(0,0.4),xaxt="n",
     xlab = "",
     ylab = "F1-Score",cex.lab=2,cex.main=2,cex.axis=2)
yticks_val <- pretty_breaks(n=10)(x)
axis(1, at=yticks_val, lab=percent(yticks_val),cex.axis=2)
polygon(x = c(x,rev(x)), y = c(f1.en+fsd.en,rev(f1.en-fsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,f1.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(f1.xg+fsd.xg,rev(f1.xg-fsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,f1.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(f1.svm+fsd.svm,rev(f1.svm-fsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,f1.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(f1.lstm+fsd.lstm,rev(f1.lstm-fsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,f1.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(f1.dnn+fsd.dnn,rev(f1.dnn-fsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

legend(1.05,0.22, bty = "n", pch=20,
       legend=c("Elastic net","XGBoost","SVM","LSTM","DNN"),
       col=c("orange","red","purple","royalblue2","chartreuse4"), 
       pt.cex = 2,cex = 2, ncol=1, xjust=0.5,x.intersp=0.3, y.intersp=0.3,)




precision.en<-c(0.2938,0.3115,0.3286,0.3310,0.3339,0.3353,0.3455,0.3512,0.3498,0.3549)
psd.en<-c(0.0415,0.0264,0.0226,0.0136,0.0160,0.0140,0.0265,0.0205,0.0132,0.0112)
precision.xg<-c(0.2863,0.3067,0.3099,0.3166,0.3137,0.3105,0.3104,0.3184,0.3154,0.3136)
psd.xg<-c(0.0360,0.0249,0.0208,0.0126,0.0161,0.0081,0.0087,0.0115,0.0180,0.0141)
precision.svm<-c(0.1533,0.1997,0.2490,0.2686,0.2847,0.2874,0.3033,0.3090,0.3162,0.3247)
psd.svm<-c(0.0180,0.0160,0.0270,0.0177,0.0187,0.0188,0.0119,0.0133,0.0133,0.0135)
precision.lstm<-c(0.1210,0.2871,0.3153,0.3150,0.3237,0.3236,0.3235,0.3234,0.3203,0.3143)
psd.lstm<-c(0.0886,0.0274,0.0222,0.0223,0.0144,0.0144,0.0185,0.0217,0.0106,0.0172)
precision.dnn<-c(0.2149,0.2402,0.2687,0.2753,0.2844,0.2830,0.2973,0.2918,0.2981,0.2907)
psd.dnn<-c(0.0291,0.0079,0.0265,0.0365,0.0268,0.0177,0.0041,0.0126,0.0237,0.0239)



recall.en<-c(0.3446,0.3758,0.3699,0.3714,0.3845,0.3839,0.3802,0.3776,0.3864,0.3870)
rsd.en<-c(0.0524,0.0286,0.0312,0.0264,0.0222,0.0204,0.0158,0.0137,0.0126,0.0205)
recall.xg<-c(0.3447,0.3679,0.3544,0.3460,0.3570,0.3607,0.3608,0.3530,0.3531,0.3501)
rsd.xg<-c(0.0521,0.0270,0.0263,0.0225,0.0204,0.0206,0.0249,0.0231,0.0180,0.0148)
recall.svm<-c(0.2389,0.3028,0.3206,0.3415,0.3457,0.3557,0.3546,0.3671,0.3567,0.3562)
rsd.svm<-c(0.0464,0.0448,0.0330,0.0290,0.0201,0.0212,0.0312,0.0298,0.0189,0.0206)
recall.lstm<-c(0.0550,0.2208,0.2753,0.3205,0.3213,0.3322,0.3330,0.3387,0.3387,0.3418)
rsd.lstm<-c(0.0443,0.0330,0.0233,0.0269,0.0201,0.0212,0.0276,0.0281,0.0214,0.0223)
recall.dnn<-c(0.3055,0.3169,0.3348,0.3360,0.3365,0.3307,0.3361,0.3416,0.3390,0.3359)
rsd.dnn<-c(0.0421,0.0369,0.0258,0.0337,0.0371,0.0231,0.0248,0.0211,0.0265,0.0241)





f1.en<-c(0.3153,0.3399,0.3472,0.3496,0.3571,0.3576,0.3612,0.3637,0.3671,0.3699)
fsd.en<-c(0.0386,0.0222,0.0206,0.0155,0.0154,0.0120,0.0135,0.0146,0.0106,0.0110)
f1.xg<-c(0.3053,0.3338,0.3296,0.3301,0.3335,0.3335,0.3332,0.3344,0.3326,0.3307)
fsd.xg<-c(0.0357,0.0212,0.0148,0.0164,0.0137,0.0110,0.0109,0.0131,0.0109,0.0130)
f1.svm<-c(0.1852,0.2394,0.2793,0.2978,0.3120,0.3175,0.3261,0.3347,0.3349,0.3394)
fsd.svm<-c(0.0227,0.0198,0.0239,0.0138,0.0172,0.0164,0.0131,0.0129,0.0112,0.0125)
f1.lstm<-c(0.0749,0.2482,0.2935,0.3065,0.3171,0.3267,0.3272,0.3294,0.3287,0.3269)
fsd.lstm<-c(0.0191,0.0268,0.0199,0.0202,0.0154,0.0154,0.0155,0.0135,0.0097,0.0145)
f1.dnn<-c(0.2451,0.2885,0.2974,0.2999,0.3063,0.3148,0.3149,0.3121,0.3159,0.3106)
fsd.dnn<-c(00.0129,0.0186,0.0227,0.0218,0.0191,0.0165,0.0122,0.0081,0.0150,0.0157)






par(mar = c(0, 0, 4.1,0 ))
with(
  plot(x,precision.en, type = "b",col = "orange", font.main=1,main="COPD (6449/205238)",ylim = c(0,0.4),xaxt="n",yaxt="n",
       ylab = "Precision",cex.lab=2,cex.main=2,cex.axis=2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(precision.en+psd.en,rev(precision.en-psd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,precision.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(precision.xg+psd.xg,rev(precision.xg-psd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,precision.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(precision.svm+psd.svm,rev(precision.svm-psd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,precision.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(precision.lstm+psd.lstm,rev(precision.lstm-psd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,precision.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(precision.dnn+psd.dnn,rev(precision.dnn-psd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(0, 0, 0, 0))
with(plot(x,recall.en, type = "b",col = "orange", ylim = c(0,0.5),xaxt="n",yaxt="n",
          ylab = "Recall",cex.lab=1.2,cex.main=1.2,cex.axis=2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(recall.en+rsd.en,rev(recall.en-rsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,recall.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(recall.xg+rsd.xg,rev(recall.xg-rsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,recall.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(recall.svm+rsd.svm,rev(recall.svm-rsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,recall.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(recall.lstm+rsd.lstm,rev(recall.lstm-rsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,recall.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(recall.dnn+rsd.dnn,rev(recall.dnn-rsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(6.1, 0, 0, 0))
plot(x,f1.en, type = "b",col = "orange", ylim = c(0,0.4),xaxt="n",yaxt="n",
     sub = "Proportion of subsets",
     xlab = "",
     ylab = "F1-Score",cex.lab=2,cex.main=2,cex.axis=2,cex.sub=2)
yticks_val <- pretty_breaks(n=10)(x)
axis(1, at=yticks_val, lab=percent(yticks_val),cex.axis=2)
polygon(x = c(x,rev(x)), y = c(f1.en+fsd.en,rev(f1.en-fsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,f1.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(f1.xg+fsd.xg,rev(f1.xg-fsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,f1.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(f1.svm+fsd.svm,rev(f1.svm-fsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,f1.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(f1.lstm+fsd.lstm,rev(f1.lstm-fsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,f1.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(f1.dnn+fsd.dnn,rev(f1.dnn-fsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)



precision.en<-c(0.0619,0.1259,0.1568,0.1701,0.2113,0.2197,0.2500,0.2546,0.2736,0.2783)
psd.en<-c(0.0282,0.0459,0.0357,0.0428,0.0353,0.0211,0.0362,0.0213,0.0220,0.0219)
precision.xg<-c(0.0319,0.0507,0.0547,0.0602,0.0616,0.0663,0.0662,0.0668,0.0624,0.0635)
psd.xg<-c(0.0156,0.0178,0.0119,0.0140,0.0122,0.0104,0.0271,0.0068,0.0079,0.0063)
precision.svm<-c(0.0478,0.1119,0.1234,0.1345,0.1616,0.1758,0.1804,0.2001,0.2287,0.2310)
psd.svm<-c(0.0272,0.0278,0.0295,0.0311,0.0238,0.0204,0.0180,0.0232,0.0200,0.0244)
precision.lstm<-c(0.0341,0.0419,0.1509,0.1605,0.1655,0.1754,0.1680,0.1606,0.1708,0.1833)
psd.lstm<-c(0.0250,0.0270,0.0340,0.0494,0.0396,0.0664,0.0449,0.0416,0.0472,0.0290)
precision.dnn<-c(0.0398,0.0426,0.0463,0.0437,0.0476,0.0527,0.0464,0.0432,0.0549,0.0551)
psd.dnn<-c(0.0271,0.0339,0.0377,0.0227,0.0131,0.0198,0.0254,0.0176,0.0209,0.0218)


recall.en<-c(0.1573,0.2161,0.1959,0.2097,0.2163,0.2504,0.2291,0.2579,0.2560,0.2704)
rsd.en<-c(0.1306,0.0471,0.0413,0.0343,0.0320,0.0225,0.0292,0.0280,0.0353,0.0304)
recall.xg<-c(0.1490,0.1280,0.1394,0.1432,0.1702,0.1680,0.1908,0.1767,0.1965,0.1610)
rsd.xg<-c(0.1016,0.0599,0.0298,0.0354,0.0361,0.0373,0.0400,0.0290,0.0567,0.0392)
recall.svm<-c(0.1413,0.1405,0.1456,0.1376,0.1767,0.2027,0.2132,0.2271,0.2147,0.2358)
rsd.svm<-c(0.0985,0.0679,0.0365,0.0447,0.0397,0.0423,0.0417,0.0390,0.0298,0.0284)
recall.lstm<-c(0.0554,0.0511,0.0721,0.0823,0.0929,0.1139,0.1198,0.1261,0.1278,0.1279)
rsd.lstm<-c(0.0003,0.0012,0.0322,0.0364,0.0301,0.0244,0.0414,0.0221,0.0267,0.0320)
recall.dnn<-c(0.1036,0.1144,0.1387,0.1517,0.1597,0.1690,0.1702,0.1766,0.1802,0.1840)
rsd.dnn<-c(0.1006,0.0484,0.0562,0.0415,0.0406,0.0577,0.0496,0.0440,0.0589,0.0383)




f1.en<-c(0.0814,0.1557,0.1704,0.1855,0.2110,0.2327,0.2381,0.2551,0.2621,0.2731)
fsd.en<-c(0.0357,0.0474,0.0264,0.0325,0.0235,0.0119,0.0278,0.0168,0.0165,0.0184)
f1.xg<-c(0.0490,0.0701,0.0765,0.0839,0.0885,0.0940,0.0933,0.0964,0.0933,0.0899)
fsd.xg<-c(0.0219,0.0228,0.0108,0.0183,0.0128,0.0127,0.0115,0.0092,0.0098,0.0101)
f1.svm<-c(0.0659,0.1192,0.1316,0.1329,0.1656,0.1854,0.1938,0.2104,0.2201,0.2313)
fsd.svm<-c(0.0310,0.0392,0.0295,0.0301,0.0239,0.0226,0.0230,0.0198,0.0178,0.0120)
f1.lstm<-c(0.0273,0.0449,0.0975,0.1062,0.1146,0.1338,0.1352,0.1393,0.1393,0.1483)
fsd.lstm<-c(0.0030,0.0053,0.0354,0.0415,0.0269,0.0281,0.0352,0.0249,0.0208,0.0250)
f1.dnn<-c(0.0402,0.0437,0.0430,0.0508,0.0547,0.0598,0.0635,0.0642,0.0751,0.0857)
fsd.dnn<-c(0.0341,0.0354,0.0348,0.0296,0.0187,0.0262,0.0319,0.0199,0.0204,0.0264)


par(mar = c(0, 0, 4.1, 2.1))
with(
  plot(x,precision.en, type = "b",col = "orange", font.main=1,main="Cancer (1202/205238)",ylim = c(0,0.4),xaxt="n",yaxt="n",
       ylab = "Precision",cex.lab=2,cex.main=2,cex.axis=2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(precision.en+psd.en,rev(precision.en-psd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,precision.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(precision.xg+psd.xg,rev(precision.xg-psd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,precision.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(precision.svm+psd.svm,rev(precision.svm-psd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,precision.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(precision.lstm+psd.lstm,rev(precision.lstm-psd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,precision.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(precision.dnn+psd.dnn,rev(precision.dnn-psd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(0, 0, 0, 2.1))
with(plot(x,recall.en, type = "b",col = "orange", ylim = c(0,0.5),xaxt="n",yaxt="n",
          ylab = "Recall",cex.lab=1.2,cex.main=1.2))
# yticks_val <- pretty_breaks(n=10)(x)
# axis(1, at=yticks_val, lab=percent(yticks_val))
polygon(x = c(x,rev(x)), y = c(recall.en+rsd.en,rev(recall.en-rsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,recall.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(recall.xg+rsd.xg,rev(recall.xg-rsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,recall.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(recall.svm+rsd.svm,rev(recall.svm-rsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,recall.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(recall.lstm+rsd.lstm,rev(recall.lstm-rsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,recall.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(recall.dnn+rsd.dnn,rev(recall.dnn-rsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)

par(mar = c(6.1, 0, 0, 2.1))
plot(x,f1.en, type = "b",col = "orange", ylim = c(0,0.4),xaxt="n",yaxt="n",
     xlab = "",
     ylab = "F1-Score",cex.lab=1.2,cex.main=1.2,cex.axis=2)
yticks_val <- pretty_breaks(n=10)(x)
axis(1, at=yticks_val, lab=percent(yticks_val),cex.axis=2)
polygon(x = c(x,rev(x)), y = c(f1.en+fsd.en,rev(f1.en-fsd.en)), col = adjustcolor("orange", alpha.f = 0.1), border =  NA)
lines(x,f1.xg, type = "b", col = "red")
polygon(x = c(x,rev(x)), y = c(f1.xg+fsd.xg,rev(f1.xg-fsd.xg)), col = adjustcolor("red", alpha.f = 0.1), border =  NA)
lines(x,f1.svm, type = "b", col = "purple")
polygon(x = c(x,rev(x)), y = c(f1.svm+fsd.svm,rev(f1.svm-fsd.svm)), col = adjustcolor("purple", alpha.f = 0.1), border =  NA)
lines(x,f1.lstm, type = "b", col = "royalblue2")
polygon(x = c(x,rev(x)), y = c(f1.lstm+fsd.lstm,rev(f1.lstm-fsd.lstm)), col = adjustcolor("royalblue2", alpha.f = 0.1), border =  NA)
lines(x,f1.dnn, type = "b", col = "chartreuse4")
polygon(x = c(x,rev(x)), y = c(f1.dnn+fsd.dnn,rev(f1.dnn-fsd.dnn)), col = adjustcolor("chartreuse4", alpha.f = 0.1), border =  NA)





