import numpy as np
import pandas as pd
import xgboost as xgb
from matplotlib import pyplot as plt
from numpy import column_stack
from sklearn import metrics
from sklearn.model_selection import StratifiedShuffleSplit

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
test = ['source/data1/test10%.csv', 'source/data2/test10%.csv', 'source/data3/test10%.csv', 'source/data4/test10%.csv',
        'source/data5/test10%.csv', 'source/data6/test10%.csv', 'source/data7/test10%.csv', 'source/data8/test10%.csv',
        'source/data9/test10%.csv', 'source/data10/10%test.csv']
train = ['source/data1/train10%.csv', 'source/data2/train10%.csv', 'source/data3/train10%.csv',
         'source/data4/train10%.csv', 'source/data5/train10%.csv', 'source/data6/train10%.csv',
         'source/data7/train10%.csv', 'source/data8/train10%.csv', 'source/data9/train10%.csv',
         'source/data10/10%train.csv']
result = ['E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_1.csv', 'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_2.csv',
          'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_3.csv', 'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_4.csv',
          'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_5.csv', 'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_6.csv',
          'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_7.csv', 'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_8.csv',
          'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_9.csv', 'E:/基因预测/XGData10%二次/XG-AsthmaStatusTest10%_10.csv'
          ]
i = 1
auc_array = []
precision_array = []
recall_array = []
f1_array = []
threshold_array = []
while i < 11:
    df1 = pd.read_csv(train[i - 1]).fillna(0)
    train_X = pd.concat([df1.iloc[:, 9:], df1.iloc[:, 1:6]], axis=1)
    train_Y = df1.iloc[:, 6]
    df2 = pd.read_csv(test[i - 1]).fillna(0)
    test_X = pd.concat([df2.iloc[:, 9:], df2.iloc[:, 1:6]], axis=1)

    test_Y = df2.iloc[:, 6]
    dtrain = xgb.DMatrix(train_X, train_Y)
    dtest = xgb.DMatrix(test_X, test_Y)

    param = {'objective': 'binary:logistic', "eta": 0.1, "max_depth": 5,
             "min_child_weight": 4,
             "gamma": 0.0,
             "subsample": 0.8,
             "colsample_bytree": 0.8,
             "reg_alpha": 60,
             "learning_rate": 0.1,
             "nthread": 4,
             "max_delta_step": 1,
             "reg_lambda": 2,
             "seed": 27
             }
    sfolder = StratifiedShuffleSplit(n_splits=10, random_state=2)
    sum = 0
    count = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th']
    for train_idx, valid_idx in sfolder.split(train_X, train_Y):
        # print('Train index: %s | test index: %s' % (train_idx, valid_idx))
        train_X0 = train_X.iloc[train_idx, :]
        train_Y0 = train_Y.iloc[train_idx]
        test_X0 = train_X.iloc[valid_idx, :]
        test_Y0 = train_Y.iloc[valid_idx]
        dtrain0 = xgb.DMatrix(train_X0, train_Y0)
        dtest0 = xgb.DMatrix(test_X0, test_Y0)
        # watchlist = [(dtrain0, 'train'), (dtest0, 'eval')]
        bst0 = xgb.train(param, dtrain0, verbose_eval=1, num_boost_round=100)
        preds = bst0.predict(dtest0)
        y_pred = preds.copy()
        thresholds = np.arange(0, 0.2, 0.01)
        max = 0
        t = 0
        for threshold_index, threshold in enumerate(thresholds):
            y_pred[preds >= threshold] = 1
            y_pred[preds < threshold] = 0
            precision = metrics.precision_score(test_Y0, y_pred)
            recall = metrics.recall_score(test_Y0, y_pred)
            F1 = metrics.f1_score(test_Y0, y_pred)
            if F1 > max:
                max = F1
                t = threshold
        sum += t
        print('10%交叉验证测试集中AsthmaStatus的最佳阈值：', t, '   ', '最佳F1值：', max)
    newThre = sum / 10
    print('第', i, '个10%数据集AsthmaStatus最终阈值为：', newThre)
    threshold_array.append(newThre)
    bst = xgb.train(param, dtrain, verbose_eval=1, num_boost_round=100)

    print('第', i, '个10%数据集测试集结果')
    preds2 = bst.predict(dtest)
    prob_data = np.array(preds2)
    data = column_stack((prob_data, test_Y))

    # 自己设定阈值
    y_pred2 = preds2.copy()
    y_pred2[preds2 >= newThre] = 1
    y_pred2[y_pred2 != 1] = 0
    auc = metrics.roc_auc_score(test_Y, preds2)
    print('auc:', auc)
    precision = metrics.precision_score(test_Y, y_pred2)
    print('precision:', precision)
    recall = metrics.recall_score(test_Y, y_pred2)
    print('recall:', recall)
    F1 = metrics.f1_score(test_Y, y_pred2)
    print('f1_score:', F1)
    print('混淆矩阵', metrics.confusion_matrix(test_Y, y_pred2))
    print(metrics.classification_report(test_Y, y_pred2))
    precision_array.append(precision)
    recall_array.append(recall)
    f1_array.append(F1)
    auc_array.append(auc)
    data1 = pd.DataFrame(data, columns=('prob', 'actual'))
    data1.to_csv(result[i - 1])
    print('写入文件成功！')
    i += 1
print('Asthma10%数据集测试集10次平均指标如下')
print('平均阈值：', np.mean(threshold_array))
print('平均auc：', np.mean(auc_array))
print('平均precision：', np.mean(precision_array))
print('平均recall：', np.mean(recall_array))
print('平均F1-score：', np.mean(f1_array))
