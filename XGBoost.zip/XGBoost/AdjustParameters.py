import pandas as pd
from xgboost import XGBClassifier
from sklearn import metrics
from sklearn.model_selection import GridSearchCV

df1 = pd.read_csv("source/10%数据/train10%10.csv").fillna(0)
train_X = pd.concat([df1.iloc[:, 9:], df1.iloc[:, 1:6]], axis=1)
train_Y = df1.iloc[:, 6]
df2 = pd.read_csv("source/10%数据/test10%10.csv").fillna(0)
test_X = pd.concat([df2.iloc[:, 9:], df2.iloc[:, 1:6]], axis=1)
test_Y = df2.iloc[:, 6]

clf0 = XGBClassifier()
clf0.fit(train_X, train_Y)
prob_y = clf0.predict(test_X)
accuracy = metrics.accuracy_score(test_Y, prob_y)
print('accuarcy:%.2f%%' % (accuracy * 100))
precision = metrics.precision_score(test_Y, prob_y)
print('precision:%.2f%%' % (precision * 100))
recall = metrics.recall_score(test_Y, prob_y)
print('recall:%.2f%%' % (recall * 100))
f1 = metrics.f1_score(test_Y, prob_y)
print('f1_score:%.2f%%' % (f1 * 100))
print('混淆矩阵', metrics.confusion_matrix(test_Y, prob_y))
print(metrics.classification_report(test_Y, prob_y))
fpr_Nb, tpr_Nb, thresholds = metrics.roc_curve(test_Y, prob_y, pos_label=1)
aucval = metrics.auc(fpr_Nb, tpr_Nb)  # 计算auc的取值
print('查看默认值时的auc的值')
print(aucval)


#使用网格搜索法依次调参
param_test1 = {
    'max_depth': range(3, 10, 2),  # 3
    'min_child_weight': range(1, 6, 2)  # 5
}
param_test2 = {
    'max_depth': [4, 5, 6],  # 5
    'min_child_weight': [4, 5, 6]  # 4
}
param_test3 = {
    'gamma': [i / 10.0 for i in range(0, 5)]}  # 0.0,评分0.6455
param_test4 = {
    'subsample': [i / 10.0 for i in range(6, 10)],  # 0.8
    'colsample_bytree': [i / 10.0 for i in range(6, 10)]  # 0.8  评分:0.6455
}
param_test6 = {
    'reg_alpha': [1e-5, 1e-2, 0.1, 1, 100]  # 100  0.6497
}
param_test5 = {
    'reg_alpha': [40, 50, 60, 70, 80]  # 60  0.6588
}
param_test7 = {
    'scale_pos_weight': [1, 5, 10]
}
tuned_parameters = [{'n_estimators': [80, 100, 120],  # 100
                     'learning_rate': [0.1, 0.01, 0.05],  # 0.1  0.6371
                     }]
param_test8 = {
    'reg_lambda': [0.01,0.1, 1, 10,100]
}
param_test9 = {
   'reg_lambda': [0.5, 1, 4, 8] #4
}
param_test10 = {
    'reg_lambda': [2, 4, 6, 8]
}


gsearch1 = GridSearchCV(
    estimator=XGBClassifier(
        max_depth=5,
        min_child_weight=4,
        gamma=0.0,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=60,
        n_estimators=100,
        learning_rate=0.1,
        objective='binary:logistic',
        nthread=4,
        scale_pos_weight=1,
        seed=27),
    param_grid=param_test7,
    scoring='roc_auc',
    n_jobs=4,
    cv=5)
gsearch1.fit(train_X, train_Y)
print(gsearch1.best_params_, gsearch1.best_score_)
