import csv

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator
from numpy import argmax, column_stack
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedShuffleSplit
from imblearn.over_sampling import SMOTE
import random
import warnings


warnings.filterwarnings("ignore")
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, roc_curve
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import hamming_loss
import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.svm import LinearSVC
# Plot Precision-Recall curve using sklearn.
from sklearn.metrics import precision_recall_curve
train_data = pd.read_csv('70train.csv', quoting=csv.QUOTE_NONE).fillna(0)
test_data = pd.read_csv('70test.csv', quoting=csv.QUOTE_NONE).fillna(0)
categories = ['AsthmaStatus', 'COPDStatus', 'CancerStatus']
# categories = ['CancerStatus']
x_train = pd.concat([train_data.iloc[:,9:],train_data.iloc[:,1:6]],axis=1)
y_train = train_data.iloc[:, 6:9]
print(train_data.shape)
print(test_data.shape)
x_test = pd.concat([test_data.iloc[:,9:],test_data.iloc[:,1:6]],axis=1)
y_test = test_data.iloc[:, 6:9]


def find_nearest(array, value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return array[idx]

def Find(list, x):
    for i, item in enumerate(list):
        if item == x:
            return i
    else:
        return None

def mscatter(x, y, ax=None, m=None, **kw):
    import matplotlib.markers as mmarkers
    if not ax: ax = plt.gca()
    sc = ax.scatter(x, y, **kw)
    if (m is not None) and (len(m) == len(x)):
        paths = []
        for marker in m:
            if isinstance(marker, mmarkers.MarkerStyle):
                marker_obj = marker
            else:
                marker_obj = mmarkers.MarkerStyle(marker)
            path = marker_obj.get_path().transformed(
                marker_obj.get_transform())
            paths.append(path)
        sc.set_paths(paths)
    return sc

for category in categories:
    svc = LinearSVC(penalty='l1', multi_class='ovr', dual=False)
    clf = CalibratedClassifierCV(svc)
    sfolder = StratifiedShuffleSplit(n_splits=10, random_state=2)
    sum = 0
    count = ['1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th']
    i = 0
    for train_idx, valid_idx in sfolder.split(x_train, train_data[category]):
        # print('Train index: %s | test index: %s' % (train_idx, valid_idx))
        train_X = x_train.iloc[train_idx, :]
        train_Y = train_data[category].iloc[train_idx]
        test_X = x_train.iloc[valid_idx, :]
        test_Y = train_data[category].iloc[valid_idx]
        clf.fit(train_X, train_Y)
        prob_y = clf.predict_proba(test_X)[:, 1]
        prey_y = prob_y.copy()
        thresholds = np.arange(0, 1, 0.01)
        max = 0
        t = 0
        i = i+1
        threshold_array = []
        precision_array = []
        recall_array = []
        f1_array = []
        for threshold_index, threshold in enumerate(thresholds):
            prey_y[prob_y >= threshold] = 1
            prey_y[prob_y < threshold] = 0
            precision = metrics.precision_score(test_Y, prey_y)
            recall = metrics.recall_score(test_Y,prey_y)
            f1 = metrics.f1_score(test_Y, prey_y)
            threshold_array.append(threshold)
            precision_array.append(precision)
            recall_array.append(recall)
            f1_array.append(f1)
            if f1 > max:
                max = f1
                t = threshold
        sum += t
        # plt.figure(figsize=(15,7))
        # plt.plot(threshold_array, precision_array, 'b-', label="Precision")
        # plt.plot(threshold_array, recall_array, 'g-', label="Recall")
        # plt.plot(threshold_array, f1_array, 'r-', label="F1")
        # x_major_locator = MultipleLocator(0.05)
        # y_major_locator = MultipleLocator(0.05)
        # ax = plt.gca()
        # # ax为两条坐标轴的实例
        # ax.xaxis.set_major_locator(x_major_locator)
        # ax.yaxis.set_major_locator(y_major_locator)
        # plt.legend()
        # plt.xlabel('Threshold')
        # plt.ylabel('Score')
        # plt.title('{} the {} cross validation'.format(category, count[i - 1]))
        print(category,'的最佳阈值：', t, '   ', '最佳F1值：', max)
        # plt.show()

    best_threshold = sum/10
    print(category,' 10次阈值均值:',sum / 10)
    # best_threshold = 0.026999999999999996
    # print(category,' 10次阈值均值:',best_threshold)

    #更改训练集or测试集
    clf.fit(x_train, train_data[category])
    y_pred = clf.predict_proba(x_test)
    y_pred = y_pred[:, 1]
    y_true = test_data[category]

    y_prey = clf.predict_proba(x_test)[:,1]

    y_pred[y_pred >= best_threshold] = 1
    y_pred[y_pred < best_threshold] = 0

    prob_data = np.array(y_prey)
    data = column_stack((prob_data, test_data[category]))
    data1 = pd.DataFrame(data, columns=('prob', 'actual'))

    alldata = data1.sort_values(by='prob')

    crossPoint = find_nearest(alldata.loc[:, 'prob'], best_threshold)
    crossX = Find(alldata.loc[:, 'prob'], crossPoint)
    print(crossPoint)
    print(crossX)

    x = np.arange(0, test_data.shape[0])
    y = alldata.loc[:, 'prob']

    c = alldata.loc[:, 'actual']
    m = {0: '.', 1: '*'}
    map_color = {0:'b',1:'r'}
    map_size = {0:10,1:40}
    cm = list(map(lambda x: m[x], c))  # 将相应的标签改成对应的marker
    color = list(map(lambda x:map_color[x],c))
    size = list(map(lambda x: map_size[x], c))
    # print(cm)

    fig, ax = plt.subplots(figsize = (16,9))
    scatter = mscatter(x, y, c=color, m=cm, ax=ax, cmap=plt.cm.RdYlBu,s=size)
    x_major_locator = MultipleLocator(1000)
    y_major_locator = MultipleLocator(0.1)
    ax = plt.gca()
    # ax为两条坐标轴的实例
    ax.xaxis.set_major_locator(x_major_locator)
    ax.yaxis.set_major_locator(y_major_locator)
    plt.xlim([0,test_data.shape[0]])
    plt.ylim([0,0.5])
    plt.xlabel("Samples")
    plt.ylabel("Probability")
    plt.title("Probability and True Value of {}".format(category))
    plt.axhline(y=best_threshold, color='y', label='best_thresholid')
    plt.axvline(x=crossX, color='g', label='vertical_line')
    plt.legend()
    plt.show()

    fpr, tpr, thresholds = roc_curve(y_true, y_pred)
    roc_auc = metrics.auc(fpr, tpr)
    print('Precision {}'.format(metrics.precision_score(y_true, y_pred)))
    print('Recall {}'.format(metrics.recall_score(y_true, y_pred)))
    print('F1 Score {}'.format(metrics.f1_score(y_true, y_pred)))
    # print('Hamming Loss is {}'.format(round(hamming_loss(y_true, y_pred), 2)))
    print('Exact Match score is {}'.format(accuracy_score(y_true, y_pred)))
    print('AUC Value is {}\n'.format(roc_auc))
    print('Confusion Matrix is \n {}\n'.format(metrics.confusion_matrix(y_true, y_pred)))
    print('The classification of the model\n {}\n'.format(
        metrics.classification_report(y_true, y_pred)))
    plt.figure(figsize=(6, 6))
    plt.title('{} Validation ROC'.format(category))
    plt.plot(fpr, tpr, 'b', label='Val AUC = %0.3f' % roc_auc)
    plt.legend(loc='lower right')
    plt.plot([0, 1], [0, 1], 'r--')
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.ylabel('True Positive Rate')
    plt.xlabel('False Positive Rate')
    plt.show()
    print("\n\n")



